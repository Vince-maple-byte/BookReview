package com.example.finalproject;

public class Review {
    private final String reviewer;
    private final String review;

    public Review(String reviewer, String review) {
        this.reviewer = reviewer;
        this.review = review;
    }
    public String getReviewer() {
        return reviewer;
    }

    public String getReview() {
        return review;
    }
}
