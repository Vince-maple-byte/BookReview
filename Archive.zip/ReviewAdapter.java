package com.example.finalproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class ReviewAdapter extends ArrayAdapter<Review> {
    public ReviewAdapter(ReviewActivity context, Review[] reviews) {
        super(context, 0, reviews);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        Review review = getItem(position);

        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_review, parent, false);
        }

        // Lookup view for data population
        TextView tvReviewer = (TextView) convertView.findViewById(R.id.tvReviewer);
        TextView tvReview = (TextView) convertView.findViewById(R.id.tvReview);

        // Populate the data into the template view using the data object
        tvReviewer.setText(review.getReviewer());
        tvReview.setText(review.getReview());

        // Return the completed view to render on screen
        return convertView;
    }
}
