package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

public class ReviewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);

        // Initialize array of reviews
        Review[] reviews = new Review[] {
                new Review("John", "Great book! I loved it."),
                new Review("Jane", "Not bad, but I've read better."),
                new Review("Bob", "A must-read for any book lover."),
                // add more reviews
        };

        // Create the adapter to convert the array to views
        ReviewAdapter adapter = new ReviewAdapter(this, reviews);

        // Attach the adapter to a ListView
        ListView listView = findViewById(R.id.lvReviews);
        listView.setAdapter(adapter);
    }
}
